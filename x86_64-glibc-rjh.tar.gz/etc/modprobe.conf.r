options lnet networks=o2ib3 routes="o2ib7 10.9.104.[1,2]@o2ib3" dead_router_check_interval=50 live_router_check_interval=50 check_routers_before_use=1
options mlx4_core msi_x=1
options ib_mthca msi_x=1
options ib_mthca tune_pci=1
